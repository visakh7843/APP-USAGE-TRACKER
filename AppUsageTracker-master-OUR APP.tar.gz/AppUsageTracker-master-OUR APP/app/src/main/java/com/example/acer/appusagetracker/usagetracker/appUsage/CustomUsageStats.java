package com.example.acer.appusagetracker.usagetracker.appUsage;


import android.app.usage.UsageStats;
import android.graphics.drawable.Drawable;


public class CustomUsageStats {
    public UsageStats usageStats;
    public Drawable appIcon;
}
